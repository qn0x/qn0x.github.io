---
layout:    page
permalink: "/offline-warning/"
author:    jwillmer
weight:    5
menutitle: Offline
title:     Offline Warning
excerpt:   If you click on the link below it will render all content of the blog in one site. This can take some time!
---


If you click on the link below it will render **all** content of the blog in one site. This can take some time! The positive thing about it is that you don't need any internet connection after the site has rendered and you can print the site as pdf.

[Open the content offline]({{ "/offline" | absolute_url }})