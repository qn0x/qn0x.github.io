---
layout:    about
permalink: "/about"
author:    jdecent
keywords:  about person demo example
title:     About Jekyll Decent
menutitle: About
weight:    90
excerpt:   This page contains the curriculum vitae (CV) of the author.
--- 
<script async defer src="https://buttons.github.io/buttons.js"></script>

If you like this theme and like to show your appreciation then please leave a star in the GitHub repository or [buy me a coffee](https://www.paypal.me/jenswillmer/3) - Thank you!

<p class="github-button-container">
<a class="github-button" href="https://github.com/jwillmer/jekyllDecent" data-size="large" data-show-count="true" aria-label="Star jwillmer/jekyllDecent on GitHub">jekyllDecent</a>
</p>